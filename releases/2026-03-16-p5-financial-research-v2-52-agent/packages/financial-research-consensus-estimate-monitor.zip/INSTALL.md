# Install Consensus Estimate Monitor

## Goal
Install this shareable OpenClaw agent folder package on a target machine.

## Target location
Copy this folder to:

```text
~/.openclaw/agents/financial-research-consensus-estimate-monitor
```

The final installed layout should look like:

```text
~/.openclaw/agents/financial-research-consensus-estimate-monitor/
  workspace/
  config/
  INSTALL.md
  PACKAGE.json
```

## Steps
1. Copy this entire folder to `~/.openclaw/agents/financial-research-consensus-estimate-monitor`.
2. Open `config/openclaw.agent.financial-research-consensus-estimate-monitor.entry.json`.
3. Append that JSON object to `agents.list` in the target machine's `~/.openclaw/openclaw.json`.
4. If you prefer a wrapper snippet, merge `config/openclaw.agent.financial-research-consensus-estimate-monitor.snippet.json` into the target config instead.
5. Review `config/SECRETS.md` and fill in the target machine's provider credentials or channel tokens.
6. Restart OpenClaw Gateway.

## Skill loading
This package keeps bundled skills under:

```text
~/.openclaw/agents/financial-research-consensus-estimate-monitor/workspace/skills
```

OpenClaw loads agent-specific skills from `workspace/skills/`, so no extra global skill copy step is required for the bundled skills in this package.

## Config paths used by this package
- workspace: `~/.openclaw/agents/financial-research-consensus-estimate-monitor/workspace`
- agentDir: `~/.openclaw/agents/financial-research-consensus-estimate-monitor/agent`

## Not included
This package does not include:
- provider secrets or API keys
- login state or channel auth sessions
- routing bindings specific to the recipient's environment