﻿# PLAYBOOK.md — Copy/paste request templates

Use these templates to get consistent, high-quality outputs.

## Build something
- Goal: <one sentence>
- Constraints: <platform/version/tooling>
- Inputs: <data/API/spec>
- Output: "Plan -> Files -> Code/Output (by file path) -> Verify"

## Debug a bug
- Repro steps: ...
- Logs/errors: ...
- Related code: ...
- Output: "root cause + minimal fix + regression checklist"

## High-stakes research checks
Before finalizing an answer, include:
- assumptions and data freshness
- uncertainty or scenario ranges instead of false precision
- explicit downside / disconfirming factors
- a handoff note when a qualified human reviewer should make the final decision

