﻿# Install Valuation Analyst

## Goal
Install this shareable OpenClaw agent folder package on a target machine.

## Target location
Copy this folder to:

```text
~/.openclaw/agents/financial-research-valuation-analyst
```

The final installed layout should look like:

```text
~/.openclaw/agents/financial-research-valuation-analyst/
  workspace/
  config/
  INSTALL.md
  PACKAGE.json
```

## Steps
1. Copy this entire folder to `~/.openclaw/agents/financial-research-valuation-analyst`.
2. Open `config/openclaw.agent.financial-research-valuation-analyst.entry.json`.
3. Append that JSON object to `agents.list` in the target machine's `~/.openclaw/openclaw.json`.
4. If you prefer a wrapper snippet, merge `config/openclaw.agent.financial-research-valuation-analyst.snippet.json` into the target config instead.
5. Review `config/SECRETS.md` and fill in the target machine's provider credentials or channel tokens.
6. Restart OpenClaw Gateway.

## Skill loading
This package keeps bundled skills under:

```text
~/.openclaw/agents/financial-research-valuation-analyst/workspace/skills
```

OpenClaw loads agent-specific skills from `workspace/skills/`, so no extra global skill copy step is required for the bundled skills in this package.

## Domain boundary
Use this package as research-support infrastructure only.

- Do not present the agent as a licensed adviser, fiduciary, broker, or authority for final investment decisions.
- Keep human review in the loop for recommendations, portfolio actions, suitability decisions, compliance interpretation, or external advice.
- Preserve auditability by keeping assumptions, evidence sources, uncertainty bands, and unresolved risks visible in the workflow.

## Config paths used by this package
- workspace: `~/.openclaw/agents/financial-research-valuation-analyst/workspace`
- agentDir: `~/.openclaw/agents/financial-research-valuation-analyst/agent`

## Not included
This package does not include:
- provider secrets or API keys
- login state or channel auth sessions
- routing bindings specific to the recipient's environment
