# Qualitative Researcher

A shareable OpenClaw agent folder package for **Qualitative Researcher**.

## Package identity
- Agent ID: `software-it-qualitative-researcher`
- Industry: `industry-1-software-it`
- Role family: `user-research-experience`
- Package version: `0.1.0`
- Recommended model: `openai-codex/gpt-5.4`

## Included
- `workspace/` — agent workspace files and persona docs
- `workspace/skills/` — bundled agent-specific skills
- `config/` — install-ready config entry + snippet + secrets checklist
- `INSTALL.md` — target machine installation steps
- `PACKAGE.json` — package metadata for GitHub/library use

## Bundled skills
- coding-agent
- ui-ux-pro-max

## Install
See `INSTALL.md`.

## Important note
This repository path is a library/catalog location.
After copying this package to a target machine, the intended install path is:

```text
~/.openclaw/agents/software-it-qualitative-researcher
```