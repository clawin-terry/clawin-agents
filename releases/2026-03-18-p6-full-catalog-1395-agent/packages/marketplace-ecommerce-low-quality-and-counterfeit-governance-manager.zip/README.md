# Low-Quality and Counterfeit Governance Manager

A shareable OpenClaw agent folder package for **Low-Quality and Counterfeit Governance Manager**.

## Package identity
- Agent ID: `marketplace-ecommerce-low-quality-and-counterfeit-governance-manager`
- Industry: `industry-3-marketplace-ecommerce`
- Role family: `content-product-compliance-governance`
- Package version: `0.1.0`
- Recommended model: `openai-codex/gpt-5.4`

## Included
- `workspace/` — agent workspace files and persona docs
- `workspace/skills/` — bundled agent-specific skills
- `config/` — install-ready config entry + snippet + secrets checklist
- `INSTALL.md` — target machine installation steps
- `PACKAGE.json` — package metadata for GitHub/library use

## Bundled skills
- coding-agent

## Install
See `INSTALL.md`.

## Important note
This repository path is a library/catalog location.
After copying this package to a target machine, the intended install path is:

```text
~/.openclaw/agents/marketplace-ecommerce-low-quality-and-counterfeit-governance-manager
```