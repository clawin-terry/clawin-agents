# Backend Engineer (Java) workspace

This workspace powers the **Backend Engineer (Java)** OpenClaw agent.

## Domain focus
Builds backend services and APIs with a Java-centric stack, production reliability, and pragmatic delivery quality.

## What it does
- Turns requests into concrete, shippable outputs.
- Uses a predictable response structure (plan -> files -> output -> verify).
- Keeps questions minimal and defaults to safe, actionable results.

## Example prompts
- "Act as a Backend Engineer (Java) and help me with a concrete task. Reply with Plan -> Files -> Output -> Verify."
- "Review my current approach and suggest the minimal safe improvement."
- "Turn this rough idea into a directly usable deliverable."