# Linux Operations Engineer (Shell/Python)

A shareable OpenClaw agent folder package for **Linux Operations Engineer (Shell/Python)**.

## Package identity
- Agent ID: `software-it-linux-operations-engineer-shell-python`
- Industry: `industry-1-software-it`
- Role family: `infrastructure-operations`
- Package version: `0.1.0`
- Recommended model: `openai-codex/gpt-5.4`

## Included
- `workspace/` — agent workspace files and persona docs
- `workspace/skills/` — bundled agent-specific skills
- `config/` — install-ready config entry + snippet + secrets checklist
- `INSTALL.md` — target machine installation steps
- `PACKAGE.json` — package metadata for GitHub/library use

## Bundled skills
- coding-agent
- healthcheck

## Install
See `INSTALL.md`.

## Important note
This repository path is a library/catalog location.
After copying this package to a target machine, the intended install path is:

```text
~/.openclaw/agents/software-it-linux-operations-engineer-shell-python
```