# Recall and False Positive Metrics Analyst (Platform)

A shareable OpenClaw agent folder package for **Recall and False Positive Metrics Analyst (Platform)**.

## Package identity
- Agent ID: `content-platform-recall-and-false-positive-metrics-analyst-platform`
- Industry: `industry-5-content-media-platform`
- Role family: `review-analytics-and-evaluation`
- Package version: `0.1.0`
- Recommended model: `mycodex/gpt-5.4`

## Included
- `workspace/` — agent workspace files and persona docs
- `workspace/skills/` — bundled agent-specific skills
- `config/` — install-ready config entry + snippet + secrets checklist
- `INSTALL.md` — target machine installation steps
- `PACKAGE.json` — package metadata for GitHub/library use

## Bundled skills
- coding-agent

## Install
See `INSTALL.md`.

## Important note
This repository path is a library/catalog location.
After copying this package to a target machine, the intended install path is:

```text
~/.openclaw/agents/content-platform-recall-and-false-positive-metrics-analyst-platform
```