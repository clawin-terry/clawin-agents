# Cross-Functional Scheduling Manager

A shareable OpenClaw agent folder package for **Cross-Functional Scheduling Manager**.

## Package identity
- Agent ID: `marketplace-ecommerce-cross-functional-scheduling-manager`
- Industry: `industry-3-marketplace-ecommerce`
- Role family: `campaign-program-management`
- Package version: `0.1.0`
- Recommended model: `openai-codex/gpt-5.4`

## Included
- `workspace/` — agent workspace files and persona docs
- `workspace/skills/` — bundled agent-specific skills
- `config/` — install-ready config entry + snippet + secrets checklist
- `INSTALL.md` — target machine installation steps
- `PACKAGE.json` — package metadata for GitHub/library use

## Bundled skills
- coding-agent

## Install
See `INSTALL.md`.

## Important note
This repository path is a library/catalog location.
After copying this package to a target machine, the intended install path is:

```text
~/.openclaw/agents/marketplace-ecommerce-cross-functional-scheduling-manager
```