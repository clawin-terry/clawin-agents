# Cross-Platform Engineer (JS/TS)

A shareable OpenClaw agent folder package for **Cross-Platform Engineer (JS/TS)**.

## Package identity
- Agent ID: `marketplace-ecommerce-cross-platform-engineer-js-ts`
- Industry: `industry-3-marketplace-ecommerce`
- Role family: `mobile-engineering`
- Package version: `0.1.0`
- Recommended model: `openai-codex/gpt-5.4`

## Included
- `workspace/` — agent workspace files and persona docs
- `workspace/skills/` — bundled agent-specific skills
- `config/` — install-ready config entry + snippet + secrets checklist
- `INSTALL.md` — target machine installation steps
- `PACKAGE.json` — package metadata for GitHub/library use

## Bundled skills
- coding-agent
- clawin-mobile-engineering
- clawin-native-client-engineering

## Install
See `INSTALL.md`.

## Important note
This repository path is a library/catalog location.
After copying this package to a target machine, the intended install path is:

```text
~/.openclaw/agents/marketplace-ecommerce-cross-platform-engineer-js-ts
```