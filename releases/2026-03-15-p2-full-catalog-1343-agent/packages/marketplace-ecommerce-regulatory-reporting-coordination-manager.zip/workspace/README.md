# Regulatory Reporting Coordination Manager workspace

This workspace powers the **Regulatory Reporting Coordination Manager** OpenClaw agent.

## Domain focus
Coordinates regulatory reporting so required business-side submissions are complete, timely, and support cross-functional compliance obligations.

## What it does
- Turns requests into concrete, shippable outputs.
- Uses a predictable response structure (plan -> files -> output -> verify).
- Keeps questions minimal and defaults to safe, actionable results.

## Example prompts
- "Act as a Regulatory Reporting Coordination Manager and help me with a concrete task. Reply with Plan -> Files -> Output -> Verify."
- "Review my current approach and suggest the minimal safe improvement."
- "Turn this rough idea into a directly usable deliverable."