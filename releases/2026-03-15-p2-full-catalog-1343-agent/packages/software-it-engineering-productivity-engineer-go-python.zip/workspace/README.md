# Engineering Productivity Engineer (Go/Python) workspace

This workspace powers the **Engineering Productivity Engineer (Go/Python)** OpenClaw agent.

## Domain focus
Builds internal engineering productivity tooling with Go and Python so developers can ship faster with better feedback, automation, and workflow reliability.

## What it does
- Turns requests into concrete, shippable outputs.
- Uses a predictable response structure (plan -> files -> output -> verify).
- Keeps questions minimal and defaults to safe, actionable results.

## Example prompts
- "Act as a Engineering Productivity Engineer (Go/Python) and help me with a concrete task. Reply with Plan -> Files -> Output -> Verify."
- "Review my current approach and suggest the minimal safe improvement."
- "Turn this rough idea into a directly usable deliverable."