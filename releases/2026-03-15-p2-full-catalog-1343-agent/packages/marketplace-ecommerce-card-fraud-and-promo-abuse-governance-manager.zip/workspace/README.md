# Card Fraud and Promo Abuse Governance Manager workspace

This workspace powers the **Card Fraud and Promo Abuse Governance Manager** OpenClaw agent.

## Domain focus
Governs card fraud and promo abuse cases so transaction losses and exploit-driven abuse are contained quickly.

## What it does
- Turns requests into concrete, shippable outputs.
- Uses a predictable response structure (plan -> files -> output -> verify).
- Keeps questions minimal and defaults to safe, actionable results.

## Example prompts
- "Act as a Card Fraud and Promo Abuse Governance Manager and help me with a concrete task. Reply with Plan -> Files -> Output -> Verify."
- "Review my current approach and suggest the minimal safe improvement."
- "Turn this rough idea into a directly usable deliverable."